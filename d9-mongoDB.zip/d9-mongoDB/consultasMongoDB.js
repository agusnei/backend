//inicio mongod en carpeta base
mongod --dbpath ./base
//si no existe la base ecommerce la crea y la utiliza
use ecommerce
db
//

//DESAFIO
// 1-Agregar 10 documentos con valores distintos a las colecciones mensajes y productos. El formato de los documentos debe estar en correspondencia con el que venimos utilizando en el entregable con base de datos MariaDB.

        //Products:
        db.products.insertMany([
        {title: 'Bronco', price: 120, thumbnail: 'abc1.jpg'},
        {title: 'F100', price: 580, thumbnail: 'abc2.jpg'},
        {title: 'S10', price: 900, thumbnail: 'abc3.jpg'},
        {title: 'AMAROK', price: 1280, thumbnail: 'abc4.jpg'},
        {title: 'HILUX', price: 1700, thumbnail: 'abc5.jpg'},
        {title: 'F150', price: 2300, thumbnail: 'abc6.jpg'},
        {title: 'RANGER', price: 2860, thumbnail: 'abc7.jpg'},
        {title: 'MUSTANG', price: 3350, thumbnail: 'abc8.jpg'},
        {title: 'FRONTIER', price: 4320, thumbnail: 'abc9.jpg'},
        {title: 'FOCUS', price: 4990, thumbnail: 'abc10.jpg'}
        ])

        //Messages:
        db.messages.insertMany([
        {username: 'abc1@abc.com', localTs: Date(), message: 'hola1'},
        {username: 'abc2@abc.com', localTs: Date(), message: 'hola2'},
        {username: 'abc3@abc.com', localTs: Date(), message: 'hola3'},
        {username: 'abc4@abc.com', localTs: Date(), message: 'hola4'},
        {username: 'abc5@abc.com', localTs: Date(), message: 'hola5'},
        {username: 'abc6@abc.com', localTs: Date(), message: 'hola6'},
        {username: 'abc7@abc.com', localTs: Date(), message: 'hola7'},
        {username: 'abc8@abc.com', localTs: Date(), message: 'hola8'},
        {username: 'abc9@abc.com', localTs: Date(), message: 'hola9'},
        {username: 'abc10@abc.com', localTs: Date(), message: 'hola10'}
        ])

// 2-Definir las claves de los documentos en relación a los campos de las tablas de esa base. En el caso de los productos, poner valores al campo precio entre los 100 y 5000 pesos(eligiendo valores intermedios, ej: 120, 580, 900, 1280, 1700, 2300, 2860, 3350, 4320, 4990). 

        //////definido al insertar en punto 1 al insertar ya los datos

// 3-Listar todos los documentos en cada colección.
        db.products.find().pretty()
        db.messages.find().pretty()

// 4-Mostrar la cantidad de documentos almacenados en cada una de ellas.
        db.products.estimatedDocumentCount()
        db.messages.estimatedDocumentCount()

// 5- Realizar un CRUD sobre la colección de productos:
//     a-Agregar un producto más en la colección de productos 
        db.products.insertOne({title: 'CORVETTE', price: 2000, thumbnail: 'abcNuevo.jpg'})

//     b-Realizar una consulta por nombre de producto específico:
//         I.Listar los productos con precio menor a 1000 pesos.
                db.products.find( {price: {$lt: 1000}} )

//         II.Listar los productos con precio entre los 1000 a 3000 pesos.
                db.products.find({$and: [
                        {price: {$gte: 1000}},
                        {price: {$lte: 3000}}
                        ]})
//         III.Listar los productos con precio mayor a 3000 pesos.
                db.products.find( {price: {$gt: 3000}} )

//         IV.Realizar una consulta que traiga sólo el nombre del tercer producto más barato.
                db.products.find({},{title: 1, _id: 0}).sort({price:1}).skip(2).limit(1)

//     c-Hacer una actualización sobre todos los productos, agregando el campo stock a todos ellos con un valor de 100.
        db.products.updateMany({},{$set:{'stock': 100}})

//     d- Cambiar el stock a cero de los productos con precios mayores a 4000 pesos. 
        db.products.updateMany( {price: {$gt: 4000}}, {$set:{stock: 0}})

//     e- Borrar los productos con precio menor a 1000 pesos 
        db.products.deleteMany( {price: {$lt: 1000}} )

// 6- Crear un usuario 'pepe' clave: 'asd456' que sólo pueda leer la base de datos ecommerce. Verificar que pepe no pueda cambiar la información.
        //1- INICIO MONGOD o TIRO EL OTRO COMANDO SI YA ESTOY INICIADO
                mongod --dbpath ./base
                //ó use admin si me encuentro ya iniciado
                use admin
        //2- ME DIRIJO A ADMIN
        mongo
        show dbs 
        use admin
        //- GENERO USUARIOS DENTRO DE ADMIN
        db.createUser(
            {
            user: "pepe",
            pwd: "asd456",
            roles: [
                { role: "read", db: "ecommerce" }
            ]
            }
        )
        db.createUser(
            {
            user: "agus",
            pwd: "123",
            roles: [
                { role: "readWrite", db: "ecommerce" }
            ]
            }
        )
        //3- CIERRO AMBOS CMD E INICIO UNO NUEVO
        //- INICIO CMD MONGOD CON AUTH-AUTENTICACION
        mongod -auth --dbpath ./base
        //4- INICIO en otro cmd MONGO CON USUARIO Y PSW DEL USUARIO READ PEPE
        mongo -u pepe -p asd456
        //5- MUESTRO DOCUMENTOS
                show dbs
                //---show dbs me mostró solo ecommerce---
                use ecommerce
                db.products.find().pretty()
                //--OK LOS MUESTRA---
        //6- LUEGO VERIFICO SI FUNCIONA EL AUTH, NO DEBERIA PODER INSERTAR
            db.products.insertOne({title: 'pruebaUser', price: 123, thumbnail: 'pruebaUser.jpg'})
        ///// -----OK-NO AUTORIZADO, no puedo insertar con el usuario pepe. todo ok